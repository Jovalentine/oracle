import os
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, send_file, flash
)
from dotenv import load_dotenv
from core.pipeline import Pipeline
from core.db import MongoDB
from core.pdf_report import generate_forensic_pdf

# -----------------------------------
#           INIT
# -----------------------------------

load_dotenv()

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.getenv("SECRET_KEY", "oracle-forensic-secret")

UPLOAD_DIR = os.getenv("STORAGE_DIR", "data/uploads")
OUTPUT_DIR = "data/outputs"
REPORT_DIR = "data/reports"

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)

pipeline = Pipeline(
    yolo_weights=os.getenv("YOLO_WEIGHTS", "models/yolo/yolov8n.pt"),
    caption_model=os.getenv("CAPTION_MODEL", "Salesforce/blip-image-captioning-base"),
    storage_dir=OUTPUT_DIR
)

db = MongoDB()

# -----------------------------------
#           LOGIN
# -----------------------------------

@app.route("/", methods=["GET", "POST"])
def login():
    if "user" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        user = db.get_user(username, password)
        if user:
            session["user"] = username
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid credentials")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# -----------------------------------
#           DASHBOARD
# -----------------------------------

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    cases = db.get_cases_by_user(session["user"])
    return render_template("dashboard.html", cases=cases)

# -----------------------------------
#        NEW INVESTIGATION
# -----------------------------------

@app.route("/new", methods=["GET", "POST"])
def new_case():
    if "user" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        file = request.files.get("image")

        if not file or file.filename == "":
            flash("No image selected")
            return redirect(url_for("new_case"))

        save_path = os.path.join(UPLOAD_DIR, file.filename)
        file.save(save_path)

        # -------- AI + FORENSIC PIPELINE --------
        result = pipeline.run(save_path)

        # -------- SAVE CASE TO DB --------
        case_data = {
            "case_id": result["id"],
            "user": session["user"],
            "caption": result["caption"],
            "fault": result["fault"],
            "humans": result.get("humans", []),
            "explanation": result["explanation"],
            "image_out": result["image_out"],
            "objects": result["objects"]
        }

        db.save_case(case_data)
        print("✅ Case stored:", result["id"])

        # -------- GO TO REPORT PAGE --------
        return redirect(url_for("view_case", case_id=result["id"]))

    return render_template("new_case.html")

# -----------------------------------
#           VIEW REPORT
# -----------------------------------

@app.route("/case/<case_id>")
def view_case(case_id):
    if "user" not in session:
        return redirect(url_for("login"))

    case = db.get_case(case_id, session["user"])
    if not case:
        flash("Case not found")
        return redirect(url_for("dashboard"))

    return render_template("report.html", result=case)

# -----------------------------------
#           DELETE REPORT
# -----------------------------------

@app.route("/delete/<case_id>")
def delete_case(case_id):
    if "user" not in session:
        return redirect(url_for("login"))

    db.delete_case(case_id, session["user"])
    flash("Case deleted successfully")
    return redirect(url_for("dashboard"))

# -----------------------------------
#         DOWNLOAD IMAGE
# -----------------------------------

@app.route("/download/<path:path>")
def download(path):
    return send_file(path, as_attachment=True)

# -----------------------------------
#       PDF DOWNLOAD RESULT
# -----------------------------------

@app.get("/case/<case_id>/pdf")
def download_case_pdf(case_id):
    if "user" not in session:
        return redirect(url_for("login"))

    result = db.get_case(case_id, session["user"])
    if not result:
        flash("Case not found")
        return redirect(url_for("dashboard"))

    pdf_path = os.path.join(REPORT_DIR, f"{case_id}.pdf")

    generate_forensic_pdf(result, pdf_path)

    return send_file(pdf_path, as_attachment=True)

# -----------------------------------
#           HEALTH
# -----------------------------------

@app.route("/health")
def health():
    return {"status": "Oracle Forensic System running"}

# -----------------------------------
#           RUN
# -----------------------------------

if __name__ == "__main__":
    app.run(debug=True, port=5000)
