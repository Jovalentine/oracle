import os
from pymongo import MongoClient
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

class MongoDB:
    def __init__(self):
        uri = os.getenv("MONGO_URI")
        self.client = MongoClient(uri)
        self.db = self.client.get_database()

        # Collections
        self.users = self.db["users"]
        self.cases = self.db["cases"]

    # -------------------------------
    #            USERS
    # -------------------------------

    def get_user(self, username, password):
        return self.users.find_one({
            "username": username,
            "password": password
        })

    def add_user(self, user_data):
        return self.users.insert_one(user_data)

    # -------------------------------
    #            CASES
    # -------------------------------

    def save_case(self, case_data):
        case_data["created_at"] = datetime.utcnow()
        return self.cases.insert_one(case_data)

    def get_cases_by_user(self, username):
        return list(self.cases.find(
            {"user": username}
        ).sort("created_at", -1))

    def get_case(self, case_id, username):
        return self.cases.find_one({
            "case_id": case_id,
            "user": username
        })

    def delete_case(self, case_id, username):
        return self.cases.delete_one({
            "case_id": case_id,
            "user": username
        })
