import cv2, os, uuid
from .detector import Detector
from .captioner import Captioner
from .reasoning import fault_score, verification_layer, normalize_fault, is_vehicle
from .annotate import draw_annotations
from .geometry import iou
from .db import MongoDB


class Pipeline:
    def __init__(self, yolo_weights, caption_model, storage_dir):
        self.det = Detector(yolo_weights)
        self.cap = Captioner(caption_model)
        self.storage = storage_dir
        self.db = MongoDB()
        os.makedirs(self.storage, exist_ok=True)

    # =========================================================
    # MAIN PIPELINE
    # =========================================================
    def run(self, img_path):
        img = cv2.imread(img_path)
        objects = self.det.detect(img)

        raw_caption = self.cap.caption(img)

        vehicles, humans = self._separate_entities(objects)
        perception = self._scene_perception(vehicles, humans)
        understanding = self._scene_understanding(vehicles, humans)
        human_risk = self._human_risk_analysis(humans, vehicles)

        caption = f"{raw_caption}. {understanding}"

        vehicle_idxs = [v["obj_index"] for v in vehicles]
        primary_fault = fault_score(objects, caption)
        verified_fault = verification_layer(primary_fault, objects)
        fault = normalize_fault(verified_fault)

        annotated = draw_annotations(img, objects, fault, vehicle_idxs)

        case_id = str(uuid.uuid4())[:8]
        out_img = os.path.join(self.storage, f"{case_id}_annotated.jpg")
        cv2.imwrite(out_img, annotated)

        explanation = self._verbalize(caption, vehicles, humans, fault)

        case_data = {
            "case_id": case_id,
            "image_out": out_img,
            "perception": perception,
            "understanding": understanding,
            "human_risk": human_risk,
            "vehicles": vehicles,
            "humans": humans,
            "fault": fault,
            "explanation": explanation
        }

        self.db.save_case(case_data)
        return case_data

    # =========================================================
    # SECTION 1 – SCENE PERCEPTION
    # =========================================================
    def _scene_perception(self, vehicles, humans):
        return {
            "vehicle_count": len(vehicles),
            "human_count": len(humans),
            "vehicles": [v["id"] for v in vehicles],
            "humans": [h["id"] for h in humans]
        }

    # =========================================================
    # SECTION 2 – SCENE UNDERSTANDING
    # =========================================================
    def _scene_understanding(self, vehicles, humans):
        statements = []

        if len(vehicles) > 1:
            statements.append(f"{len(vehicles)} vehicles detected")
        elif len(vehicles) == 1:
            statements.append("single vehicle present")

        for v in vehicles:
            if v["label"] == "motorcycle" and v["fallen"]:
                statements.append(f"{v['id']} appears fallen on the roadway")

        if humans:
            statements.append(f"{len(humans)} human subject(s) near the scene")

        max_overlap = 0
        for i in range(len(vehicles)):
            for j in range(i + 1, len(vehicles)):
                ov = iou(vehicles[i]["box"], vehicles[j]["box"])
                max_overlap = max(max_overlap, ov)

        if max_overlap > 0.25:
            statements.append("heavy collision indicators observed")
        elif max_overlap > 0.10:
            statements.append("moderate collision indicators observed")
        else:
            statements.append("minor collision indicators")

        return ", ".join(statements)

    # =========================================================
    # SECTION 3 – HUMAN PRESENCE RISK ANALYSIS
    # =========================================================
    def _human_risk_analysis(self, humans, vehicles):
        risk = []

        for h in humans:
            hx1, hy1, hx2, hy2 = h["box"]
            hcx = (hx1 + hx2) / 2
            hcy = (hy1 + hy2) / 2

            min_dist = float("inf")
            for v in vehicles:
                vx1, vy1, vx2, vy2 = v["box"]
                vcx = (vx1 + vx2) / 2
                vcy = (vy1 + vy2) / 2
                dist = ((hcx - vcx)**2 + (hcy - vcy)**2) ** 0.5
                min_dist = min(min_dist, dist)

            if min_dist < 120:
                level = "High"
            elif min_dist < 220:
                level = "Medium"
            else:
                level = "Low"

            risk.append({
                "person_id": h["id"],
                "risk_level": level
            })

        return risk

    # =========================================================
    # ENTITY SEPARATION
    # =========================================================
    def _separate_entities(self, objects):
        vehicles, humans = [], []
        v_id, h_id = 1, 1

        for idx, o in enumerate(objects):
            if is_vehicle(o):
                x1, y1, x2, y2 = o["box"]
                fallen = o["name"] == "motorcycle" and (x2 - x1) > (y2 - y1) * 1.2
                vehicles.append({
                    "id": f"Vehicle-{v_id}",
                    "label": o["name"],
                    "box": o["box"],
                    "fallen": fallen,
                    "obj_index": idx
                })
                v_id += 1

            elif o["name"] == "person":
                humans.append({
                    "id": f"Person-{h_id}",
                    "box": o["box"]
                })
                h_id += 1

        return vehicles, humans

    # =========================================================
    # EXPLANATION
    # =========================================================
    def _verbalize(self, caption, vehicles, humans, fault):
        return (
            f"{caption}. "
            f"{len(humans)} human subject(s) were detected near the collision zone. "
            f"Fault attribution reflects relative vehicle involvement."
        )